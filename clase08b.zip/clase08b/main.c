#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct{
    char nombre[20];
    int legajo;
    float sueldo;
    char sexo;
}eEmpleado;

void mostrarEmpleado(eEmpleado);

int main()
{
    eEmpleado unEmpleado = {"Juan",1111,10000.75,'m'};//hardcodeo para prueba

    eEmpleado otroEmpleado;

    otroEmpleado = unEmpleado;//las estructuras pueden copiarse unas a otras con el signo =

    //eEmpleado unEmpleado;
    //unEmpleado.legajo=1234;
    //strcpy(unEmpleado.nombre,"Juan");
    //unEmpleado.sueldo=50000.50;
    //unEmpleado.sexo='m';

    //printf("Ingrese nombre: ");
    //gets(unEmpleado.nombre);
    //printf("Ingrese legajo: ");
    //scanf("%d",&unEmpleado.legajo);
    //printf("Ingrese sueldo: ");
    //scanf("%f",&unEmpleado.sueldo);
    //printf("Ingrese sexo: ");
    //fflush(stdin);
    //scanf("%c",&unEmpleado.sexo);

    mostrarEmpleado(otroEmpleado);

    return 0;
}

void mostrarEmpleado(eEmpleado empl){
    printf("\nNombre: %s\n",empl.nombre);
    printf("Legajo: %d\n",empl.legajo);
    printf("Sueldo: %.2f\n",empl.sueldo);
    printf("Sexo: %c",empl.sexo);
}
