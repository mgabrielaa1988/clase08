#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

void mifuncion(char[][20], int);

int main()
{
    char nombre[5][20]= {"juAn CARLOS","LUIs alberto","aNa juLIa","alberto","jULIO"};
    mifuncion(nombre,5);

    return 0;
}

void mifuncion(char vec[][20], int filas)
{
    int i,k;
    for(i=0; i<filas; i++)
    {
        strlwr(vec[i]);//pone en minusculas todos los caracteres
        vec[i][0]=toupper(vec[i][0]);//pone en mayuscula el primer carater

        for(k=0; k<20; k++) //k recorre las columnas
        {
            if(vec[i][k]==' ') //[i][k] es la posicion en la matriz de cada caracter
            {
                vec[i][k+1]=toupper(vec[i][k+1]);//[i][k+1] es la posicion que le sigue al espacio
            }
        }
        printf("%s\n", vec[i]);
    }
}
